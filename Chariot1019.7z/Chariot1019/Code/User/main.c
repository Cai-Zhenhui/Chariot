#include "system.h"
#include "SysTick.h"
#include "Motor.h"
#include "Sensor_inf.h"
#include "SteeringGear.h"
#include "usart.h"




void delay_s(float waittime) {
	u16 i = 0;
	u16 ms10 = (u16)(100 * waittime);
	for (i = 0; i < ms10; ++i) {
		delay_ms(10);
	}
}

void Catch() {
	TIM4->CCR3 = 0x50;//�����Ƕ�


	Back(20);//���˲���
	delay_ms(200);
	Back(0);

	//���ƻ�еצ����
	TIM4->CCR3 = 0x90;
	delay_ms(100);
	Up(1);
	delay_ms(500);
	Up(0);
}

void Place() {
	//���ƻ�еצ��΢����һ���� ����������п��ܵ���С������ƽ̨
	int i = 0x60;
	Up(1);
	TIM4->CCR3 = 0x55;
	delay_ms(200);
	Go(0);

	for (i = 0x60; i < 0x96; i+= 10) {
		TIM4->CCR4 = i;
		delay_ms(100);
	}
	delay_ms(100);
	TIM4->CCR3 = 0xa0;
}
/*
TRACK_state:
0:����ѭ��
1:������ѭ��
2:�Ҳ����ѭ��
*/
u8 Track2() {
	static u8 TRACK_state = 0;
	u8 speed =28;
	u8 speedback = 25;
	u8 pwm = 10;
	switch (TRACK_state) {
	case 0: {
		if ((SFL == 1) && (SFR == 1)) {
			Go(speed);
		}
		else if (((SFLL == 0) && (SFL == 1) && (SFR == 0) && (SFRR == 0)) || ((SFLL == 1) && (SFL == 1) && (SFR == 0) && (SFRR == 0)) || ((SFLL == 1) && (SFL == 0) && (SFR == 0) && (SFRR == 0))) {
			//Turn(0, speed + 18);
			TurnLeft(speed, pwm);
		}
		else if (((SFLL == 0) && (SFL == 0) && (SFR == 1) && (SFRR == 0)) || ((SFLL == 0) && (SFL == 0) && (SFR == 1) && (SFRR == 1)) || ((SFLL == 0) && (SFL == 0) && (SFR == 0) && (SFRR == 1))) {
			//Turn(speed + 18, 0);
			TurnRight(speed, pwm);
		}
		else if (((SFL == 0) && (SFR == 0))) {
			Go(20);
			delay_ms(200);
			if ((SLL == 1 || SLR == 1)) {
				TRACK_state = 1;//Vertical left
				DF = 0;
				Go(0);
				Up(1);
				delay_ms(800);
				Up(0);

			}
			else if ((SRL == 1) || (SRR == 1)) {
				TRACK_state = 2;//Vertical right
				DF = 1;
				Go(0);
				Up(1);
				delay_ms(800);
				Up(0);
			}
			else {
				Back(speedback);
			}
		}

		//break;
		return 0;
	}
	case 1: {
		if ((SFL == 1) && (SFR == 1)) {
			//�ſ���
			Go(0);
			//while (PAin(0) != 1) {
				//Back(25);
			//}
			//Back(0);
			Place();
			return 1;//ѭ�����
		}
		else if ((SLL == 1) && (SLR == 1)) {
			VerticalL(speed);
		}
		else if ((SLL == 1) && (SLR == 0)) {
			VerticalLLeft(speed, pwm);
		}
		else if ((SLL == 0) && (SLR == 1)) {
			VerticalLRight(speed, pwm);
		}
		else {
			Back(speedback);
		}

		//break;
		return 0;
	}
	case 2: {
		if ((SFL == 1) && (SFR == 1)) {
			//�ſ���
			Go(0);
			//while (PAin(0) != 1) {
				//Back(25);
			//}
			//Back(0);
			Place();
			return 1;//���
		}
		else if ((SRL == 1) && (SRR == 1)) {
			VerticalR(speed);
		}
		else if ((SRL == 1) && (SRR == 0)) {
			VerticalRLeft(speed, pwm);
		}
		else if ((SRL == 0) && (SRR == 1)) {
			VerticalRRight(speed, pwm);
		}
		else {
			Back(speedback);
		}

		break;
	}

	default:
		break;
	}
	return 0;
}
void Track() {
	static u8 TRACK_state = 0;
	u8 speed = 32;
	u8 speedback = 25;
	u8 pwm = 10;

	switch (TRACK_state) {
	case 0: {
		if ((SFL == 1) && (SFR == 1)) {
			Go(speed);
		}
		else if ((SFL == 1) && (SFR == 0)) {
			TurnLeft(speed, pwm);
		}
		else if ((SFL == 0) && (SFR == 1)) {
			TurnRight(speed, pwm);
		}
		else if (((SFL == 0) && (SFR == 0))) {
			Go(20);
			delay_ms(200);
			if ((SLL == 1 || SLR == 1)) {
				TRACK_state = 1;//Vertical left
			}
			else if ((SRL == 1) || (SRR == 1)) {
				TRACK_state = 2;//Vertical right
			}
			else {
				Back(speedback);
			}
		}

		break;
	}
	case 1: {
		if ((SFL == 1) && (SFR == 1)) {
			//�ſ���
			Go(0);
			//while (PAin(0) != 1) {
				//Back(25);
			//}
			//Back(0);
			Place();
			//break;
		}
		else if ((SLL == 1) && (SLR == 1)) {
			VerticalL(speed);
		}
		else if ((SLL == 1) && (SLR == 0)) {
			VerticalLLeft(speed, pwm);
		}
		else if ((SLL == 0) && (SLR == 1)) {
			VerticalLRight(speed, pwm);
		}
		else {
			Back(speedback);
		}

		break;
	}
	case 2: {
		if ((SFL == 1) && (SFR == 1)) {
			//�ſ���
			Go(0);
			//while (PAin(0) != 1) {
				//Back(25);
			//}
			//Back(0);
			Place();
			//break;
		}
		else if ((SRL == 1) && (SRR == 1)) {
			VerticalR(speed);
		}
		else if ((SRL == 1) && (SRR == 0)) {
			VerticalRLeft(speed, pwm);
		}
		else if ((SRL == 0) && (SRR == 1)) {
			VerticalRRight(speed, pwm);
		}
		else {
			Back(speedback);
		}

		break;
	}
	case 3: {
		break;
	}
	default:
		break;
	}

}


void InitALL() {
	//Initialize all the configurations here
	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);


	Motor_Init();
	Motor2_Init();
	Sensor_Init();

	SteeringGearInit();
	//�����λ
	//setMechanicalClaw(0x90);
	TIM4->CCR3 = 0x55;
	TIM4->CCR4 = 0x60;

	//USART1_Init(38400);
	//Data_USART1 = 0;
	USART2_Init(38400);
	Data_USART2 = 0;

	//Switch_Init();
	//s1 = 0; s0 = 0;
}



int main() {
	u8 speed = 30;
	u8 speedback = 25;
	u8 pwm = 20;

	InitALL();//Initialize all the configurations

	delay_ms(200);
	Down(1);
	delay_ms(600);
	Down(0);
	while (1) {//���˵�ץ��
		if ((SFLL == 1) && (SFL == 1) && (SFR == 1) && (SFRR == 1)) {
			Go(0);
			break;//����ץ����
		}
		else {
			Back(18);
		}
	}
	delay_ms(100);

	Catch();
	delay_ms(500);
	while (1) {
		if (Track2() == 1) {
			break;
		}
	}
	if (DF==0) {
		VerticalL(speed);
		delay_ms(600);
		VerticalL(0);
		while (GetHCLength() > 95) {
			VerticalR(25);
			delay_ms(12);
		}
	}
	else {
		VerticalR(speed);
		delay_ms(600);
		VerticalR(0);
		while (GetHCLength() > 95) {
			VerticalL(25);
			delay_ms(12);
		}
	}
	
	/*
	while (GetHCLength() > 95) {
		if (DF==1) {
			VerticalR(25);
		}
		else {
			VerticalL(25);
		}
		delay_ms(12);
	}
	Go(0);*/


	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);//ʹ�ܴ����ж�
	while (1) {
		//Go(12);
	}

	return 0;
}

