#ifndef __SWITCH_H
#define __SWITCH_H
/*
Description:
Pins:
PA0 ���
PA1 ����
*/


#include <system.h>
#include <stm32f10x_exti.h>
#include <SysTick.h>

extern u8 s0;
extern u8 s1;
void Switch_Init(void);

#endif
