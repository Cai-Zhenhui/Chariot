#include "RemoteControl.h"

u8 flag_start = 0;
u8 flag_end = 0;
u8 cmd = 0x00;

void Extix_Init(void) {
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);//��������ʱ��

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource13);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource14);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource15);

	//EXTI0 NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;//exti 0 �ж�ͨ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;//�����ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	//EXTI15-10 NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;//exti 0 �ж�ͨ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;//�����ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);


	EXTI_InitStructure.EXTI_Line = EXTI_Line0 | EXTI_Line13 | EXTI_Line14 | EXTI_Line15;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;//ʱ��������
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
}

void RemoteControl_Init(void) {
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = (GPIO_Pin_0 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	Extix_Init();
}

//����C
void EXTI0_IRQHandler(void) {
	USARTx_SendData(USART2, 'c');
	if (EXTI_GetITStatus(EXTI_Line0)) {
		if (flag_start) {
			cmd <<= 1;
			cmd |= 0x01;
		}
	}
	EXTI_ClearITPendingBit(EXTI_Line0);
}

/*
//����B ����0
void EXTI1_IRQHandler(void) {
	if (EXTI_GetITStatus(EXTI_Line1)) {
		//send(0x02);
		if (flag_start) {
			cmd <<= 1;
			cmd |= 0x00;
		}
	}
	EXTI_ClearITPendingBit(EXTI_Line1);
}

//����C ����1
void EXTI2_IRQHandler(void) {
	if (EXTI_GetITStatus(EXTI_Line2)) {
		//send(0x03);
		if (flag_start) {
			cmd <<= 1;
			cmd |= 0x01;
		}
	}
	EXTI_ClearITPendingBit(EXTI_Line2);
}

//����D end
void EXTI3_IRQHandler(void) {
	if (EXTI_GetITStatus(EXTI_Line3)) {
		//send(0x04);

		if (flag_start) {
			flag_start = 0;
			//flag_end = 1;
			send(cmd);

		}
	}
	EXTI_ClearITPendingBit(EXTI_Line3);
}*/

//���� B D A
void EXTI15_10_IRQHandler(void) {
	//send(cmd);
	if (EXTI_GetITStatus(EXTI_Line13)==SET) {//�ж��Ƿ����ж�13
		//PC13 D0 B����
		USARTx_SendData(USART2, 'b');
		if (flag_start) {
			
			cmd <<= 1;
			cmd |= 0x00;
		}

		EXTI_ClearITPendingBit(EXTI_Line13);
	}
	else if (EXTI_GetITStatus(EXTI_Line14) == SET) {//�ж�14
		//PC14 D1 D
		USARTx_SendData(USART2, 'd');
		if (flag_start) {
			flag_start = 0;
			flag_end = 1;//��ʾ�źŽ������
			USARTx_SendData(USART2, cmd);
		}

		EXTI_ClearITPendingBit(EXTI_Line14);
	}
	else if (EXTI_GetITStatus(EXTI_Line15) == SET) {//�ж�15
		//PC15 D2 A
		USARTx_SendData(USART2, 'a');
		flag_start = 1;//���յ���ʼ�ź�
		flag_end = 0;
		cmd = 0x00;//����cmd

		EXTI_ClearITPendingBit(EXTI_Line15);
	}
}

