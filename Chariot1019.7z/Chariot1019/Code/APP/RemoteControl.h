#ifndef _REMOTECONTROL_H
#define _REMOTECONTROL_H
/*
Description:
Pins:
PC15 D2 A
PC13 D0 B
PC0  D3 C
PC14 D1 D
Function:
Press A start receive cmd
Press B send 0
Press C send 1
Press D end
*/

#include "system.h"
#include "usart.h"

#define CMD_START	0x01 //1	Press ACD
#define CMD_END		0x02 //10	Press ACBD
#define CMD_CATCH	0x03 //11	Press ACCD
#define CMD_PLACE	0x04 //100	Press ACBBD
extern u8 flag_start ;
extern u8 flag_end ;
extern u8 cmd ;

void RemoteControl_Init(void);


#endif

