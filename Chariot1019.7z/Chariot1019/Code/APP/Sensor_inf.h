#ifndef _Sensor_inf_H
#define _Sensor_inf_H
/*
Description:
Pins:
PB11 PB12 //Sensor at Front
PB10 PB15 //Sensor at LEFT
PB13 PB14 //Sensor at Right
*/

#include "system.h"
#include "SysTick.h"

#define SFL  BIT_ADDR(GPIOB_IDR_Addr,11)
#define SFR  BIT_ADDR(GPIOB_IDR_Addr,12)
#define SFRR BIT_ADDR(GPIOC_IDR_Addr,11)
#define SFLL BIT_ADDR(GPIOC_IDR_Addr,12)
#define SLL  BIT_ADDR(GPIOC_IDR_Addr,3)
#define SLR  BIT_ADDR(GPIOB_IDR_Addr,4)//
#define SRL  BIT_ADDR(GPIOB_IDR_Addr,13)
#define SRR  BIT_ADDR(GPIOB_IDR_Addr,14)

#define HC_TRIG BIT_ADDR(GPIOC_ODR_Addr,0)
#define HC_ECHO BIT_ADDR(GPIOC_IDR_Addr,1)

void Sensor_Init(void);
u32 GetHCLength(void);

#endif
