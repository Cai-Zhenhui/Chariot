#ifndef _USART_H
#define _USART_H
/*
Description:
Pins:
PA9  TX
PA10 RX

Link:
 STM32    Other
PA 9(TX)---RX
PA10(RX)---TX

*/

#include <system.h>
#include <stm32f10x_usart.h>
#include "Motor.h"
#include <SysTick.h>

void USART1_Init(u32 BaudRate);
void USART2_Init(u32 BaudRate);

void USARTx_SendData(USART_TypeDef* USARTx, u8 data);
extern uint16_t Data_USART1;// the function USART_ReceiveData() returns a value of type uint16_t
extern uint16_t Data_USART2;

extern u16 time_Motor;
extern u16 time_Car ;
//0 ���  1 �Ҳ�
extern u8 DF;
#endif // !_USART_H

