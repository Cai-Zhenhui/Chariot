#include "Sensor_inf.h"

//������
u16 msHCcount = 0;
void Sensor_Uit_Init(void) {
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;


	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��A0 ��Ϊtrig����
	HC_TRIG = 0;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��A1 ��Ϊecho����

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	TIM_TimeBaseInitStructure.TIM_Period = 999;//������Χ
	TIM_TimeBaseInitStructure.TIM_Prescaler = 71;//Ԥ��Ƶϵ��(999+1)*(71+1)/72000=1ms
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;//����Ƶ
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM6, &TIM_TimeBaseInitStructure);

	TIM_ClearFlag(TIM6, TIM_FLAG_Update);
	TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//Preemption Priority 3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;//sub priorty 3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}

void Sensor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStructure.GPIO_Pin=(GPIO_Pin_4|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = ( GPIO_Pin_11 | GPIO_Pin_12|GPIO_Pin_3);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	Sensor_Uit_Init();
}

void TIM6_IRQHandler(void) {
	if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET) {
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
		msHCcount++;
	}
}
void OpenHC(void) {
	TIM_SetCounter(TIM6, 0);//�������
	msHCcount = 0;
	TIM_Cmd(TIM6, ENABLE);
}
void CloseHC(void) {
	TIM_Cmd(TIM6, DISABLE);
}

// Unit us
u32 GetEchoTimer(void) {
	u32 t = msHCcount * 1000 + TIM_GetCounter(TIM6);
	TIM6->CNT = 0;//����������

	return t;
}

// Unit mm
u32 GetHCLength(void) {
	u32 temp = 0;
	HC_TRIG = 1;//���͸ߵ�ƽ
	delay_us(15);//min=10us
	HC_TRIG = 0;

	while (HC_ECHO == 0) {//�ȴ��ߵ�ƽ�ĵ���
		;
	}
	OpenHC();//��ʼ��ʱ ��ʱ�ߵ�ƽ
	while (HC_ECHO == 1) {//�ȴ��͵�ƽ�ĵ���
		;
	}
	CloseHC();//������ʱ

	temp = GetEchoTimer() * 172 / 1000;
	return temp;
}

