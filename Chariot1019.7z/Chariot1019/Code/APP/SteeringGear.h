#ifndef _SteeringGear_H
#define _SteeringGear_H

/*
Description:
Pins:
PA0 L	TIM4 ch1
PA1 M	TIM4 ch2
PA2 R	TIM4 ch3
PA3 Big	TIM4 ch4

note ���4
0 1 2 3
L M R BIG
0 4 8
*/

#include <system.h>
#include <stm32f10x_tim.h>

void SteeringGearInit(void);
void setSteeringGearAngle(int angle);
void setMechanicalClaw(u8 cp);
#endif
