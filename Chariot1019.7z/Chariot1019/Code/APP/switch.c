#include <switch.h>
u8 s0 = 0;
u8 s1 = 0;
void Switch_Init(void) {
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitStructure.GPIO_Pin = (GPIO_Pin_0 | GPIO_Pin_1);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//up down����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);//��������ʱ��

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1);

	//EXTI0 NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;//exti 0 �ж�ͨ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;//�����ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	//EXTI2 NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;//exti 1�ж�ͨ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;//�����ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

//���º�߿��رպ�
void EXTI0_IRQHandler(void) {
	if (EXTI_GetITStatus(EXTI_Line0)) {
		/*delay_ms(10);//����
		if (PAin(0) == 1) {
			s0 = 1;
		}*/
		s0 = 1;

	}
	EXTI_ClearITPendingBit(EXTI_Line0);
}

//�������࿪�رպ�
void EXTI1_IRQHandler(void) {
	if (EXTI_GetITStatus(EXTI_Line1)) {
		/*delay_ms(10);
		if (PAin(1) == 1) {
			s1 = 1;
		}*/
		s1 = 1;
	}
	EXTI_ClearITPendingBit(EXTI_Line1);
}

